<template>
  <h2>My Course Goal</h2>
  <h3 v-if="showGoal">
    {{ myGoal }}
  </h3>
  <button @click="toogleGoal">
    {{ showGoal ? 'Hide' : 'Show' }} Goal
  </button>
</template>

<script>
import { ref, reactive } from 'vue';
export default {
//  setup() {
/*
========= Individual Ref ===========
const myGoal = ref('Master Vue!')
const showGoal = ref(true)
function toogleGoal() {
  showGoal.value = !showGoal.value
}
return { myGoal, showGoal, toogleGoal }; ====================================
*/
  
/*
========= Single Ref =========== 
const dataObj = ref({
  myGoal: 'Master Vue!',
  showGoal: true
})
function toogleGoal() {
  dataObj.value.showGoal = !dataObj.value.showGoal
}
    return { dataObj, toogleGoal };
====================================
*/
/* ========= Single Reactive ===========
const dataObj = reactive({
  myGoal: 'Master Vue!',
  showGoal: true
})
function toogleGoal() {
  dataObj.showGoal = !dataObj.showGoal
}
    return { dataObj, toogleGoal };
==================================== */
//  }
  data() {
    return {
      myGoal: 'Master Vue!',
      showGoal: true
    }
  },
  methods: {
    toogleGoal() {
      this.showGoal = !this.showGoal
    }
  }
}
</script>